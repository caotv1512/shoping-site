<?php if (!defined('FW')) die('Forbidden');

$curr_dir = dirname(__FILE__);

require $curr_dir .'/model/class-fw-extension-sidebars-model-sidebar.php';


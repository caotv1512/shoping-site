<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = apply_filters( 'fw_ext_sidebars_settings_options', array() );
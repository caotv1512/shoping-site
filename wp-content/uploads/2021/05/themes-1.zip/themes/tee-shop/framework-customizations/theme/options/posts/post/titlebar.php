<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = origin_render_title_bar_metabox();

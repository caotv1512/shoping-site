<?php
/**
 * Register and include third party clasess and libraries for Moonlight theme.
 *
 ** @since Ln Moonlight 1.0.0
 */

// require get_parent_theme_file_path( '/inc/vendors/class-tgm-plugin-activation.php' );

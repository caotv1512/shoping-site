# Moonlight 1.0 changelog

Version 1.0.2
Released date: 10-06-2017
* Optimze: Web speed
* Fix: Text domain
* Add: Option show/hide feature portfolio
* Fix Blog shortcode filter category
* Fix: Blog slider image
* Fix: Mobile mega menu

Version 1.0.1
Released date: 09-15-2017
* Add: Custom Typo
* Add: Dynamic color on Theme Option
* Update: Toolkit

Version 1.0
Released date: 09-14-2017
Initial release